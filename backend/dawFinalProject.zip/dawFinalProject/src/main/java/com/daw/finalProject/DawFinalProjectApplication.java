package com.daw.finalProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DawFinalProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(DawFinalProjectApplication.class, args);
	}

}
